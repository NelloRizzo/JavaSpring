package it.begear.italiancities;

import java.util.Objects;

import jakarta.persistence.*;

@Entity
@Table(name = "provinces")
public class Province {
	private int id;
	private String name;
	private String acronym;
	private Region region;

	public Province(int id, String name, String acronym, Region region) {
		this.id = id;
		this.name = name;
		this.acronym = acronym;
		this.region = region;
	}

	public Province() {
	}

	@Id
	public int getId() {
		return id;
	}

	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	public String getName() {
		return name;
	}

	@Column(columnDefinition = "CHAR(2)", nullable = false)
	public String getAcronym() {
		return acronym;
	}

	@ManyToOne
	public Region getRegion() {
		return region;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAcronym(String acronym) {
		this.acronym = acronym;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	@Override
	public int hashCode() {
		return Objects.hash(acronym);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Province other = (Province) obj;
		return Objects.equals(acronym, other.acronym);
	}

	@Override
	public String toString() {
		return "Province [id=" + id + ", name=" + name + ", acronym=" + acronym + ", region=" + region + "]";
	}
}
