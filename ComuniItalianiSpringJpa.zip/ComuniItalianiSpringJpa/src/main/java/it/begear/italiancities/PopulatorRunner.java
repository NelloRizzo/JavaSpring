package it.begear.italiancities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Component
public class PopulatorRunner implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(PopulatorRunner.class);
	@Value("classpath:data/comuni.csv")
	Resource resourceFile;

	@Autowired
	CitiesRepository cities;
	@Autowired
	ProvincesRepository provinces;
	@Autowired
	RegionsRepository regions;
	@Autowired
	AreasRepository areas;

	@Override
	public void run(String... args) throws Exception {
		var c = CitiesLoader.load(resourceFile.getInputStream());
		var p = c.stream().map(x -> x.getProvince()).toList();
		var r = p.stream().map(x -> x.getRegion()).toList();
		var a = r.stream().map(x -> x.getArea()).toList();
		areas.saveAll(a);
		logger.debug("Saved {} areas", areas.count());
		regions.saveAll(//
				r.stream().map(x -> //
				new Region(x.getId(), x.getName(), //
						areas.findById(x.getArea().getId()).orElseThrow())//
				).toList());
		logger.debug("Saved {} regions", regions.count());
		provinces.saveAll(//
				p.stream().map(x -> //
				new Province(x.getId(), x.getName(), x.getAcronym(), //
						regions.findById(x.getRegion().getId()).orElseThrow())//
				).toList());
		logger.debug("Saved {} provinces", provinces.count());
		cities.saveAll( //
				c.stream().map(x -> //
				new City(x.getId(), x.getName(), //
						provinces.findById(x.getProvince().getId()).orElseThrow(), //
						x.getCadastralCode(), x.isCapital())).toList());

		logger.debug("Saved {} cities", cities.count());
	}

}
