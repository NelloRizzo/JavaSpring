package info.ennerre.pizzeria.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import info.ennerre.pizzeria.entities.BeverageEntity;
import info.ennerre.pizzeria.entities.FoodEntity;
import info.ennerre.pizzeria.entities.ProductEntity;

public interface ProductService {
	Optional<ProductEntity> save(ProductEntity p);

	Optional<ProductEntity> addTopping(UUID productId, ProductEntity top);

	List<ProductEntity> list();

	List<FoodEntity> listFoods();

	List<BeverageEntity> listBeverages(String name);
}
