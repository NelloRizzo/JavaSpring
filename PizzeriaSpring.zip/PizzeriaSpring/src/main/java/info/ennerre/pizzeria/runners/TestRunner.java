package info.ennerre.pizzeria.runners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import info.ennerre.pizzeria.entities.BeverageEntity;
import info.ennerre.pizzeria.entities.FoodEntity;
import info.ennerre.pizzeria.repositories.ProductsRepository;
import info.ennerre.pizzeria.services.ProductService;

@Component
public class TestRunner implements CommandLineRunner {
	private static final Logger log = LoggerFactory.getLogger(TestRunner.class);
	@Autowired
	ProductService service;

	@Autowired
	ProductsRepository repo;

	@Override
	public void run(String... args) throws Exception {
		var coca = BeverageEntity.builder() //
				.withName("Coca Cola") //
				.withDescription("Coca cola in bottiglia") //
				.withSize(1).withUnit("l").build();
		var minerale = BeverageEntity.builder() //
				.withName("Acqua minerale") //
				.withDescription("Acqua minerale in bottiglia") //
				.withSize(150).withUnit("cl").build();

		var pasta = FoodEntity.builder() //
				.withDescription("Pasta in bianco") //
				.withName("Pasta bianca").build();
		service.save(coca);
		service.save(pasta);
		service.save(minerale);
		service.list().stream() //
				.filter(p -> p.getClass().equals(FoodEntity.class)) //
				.forEach(p -> log.debug("{}", p));

		repo.findAllByType(BeverageEntity.ENTITY_TYPE).forEach(p -> log.debug("{}", p));

		log.debug("Tutte le bevande");
		service.listBeverages(null).forEach(b -> log.debug("{}", b));
		var contains = "minera";
		log.debug("Tutte le bevande il cui nome contiene {}", contains);
		service.listBeverages(contains).forEach(b -> log.debug("{}", b));
	}

}
