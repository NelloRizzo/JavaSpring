package info.ennerre.pizzeria.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import info.ennerre.pizzeria.entities.BeverageEntity;
import info.ennerre.pizzeria.entities.FoodEntity;
import info.ennerre.pizzeria.entities.ProductEntity;
import info.ennerre.pizzeria.repositories.ProductsRepository;
import info.ennerre.pizzeria.services.ProductService;
import jakarta.persistence.EntityManager;

@Service
public class ProductServiceImpl extends BaseService implements ProductService {

	@Autowired
	ProductsRepository repo;;

	@Override
	public Optional<ProductEntity> save(ProductEntity p) {
		try {
			return Optional.of(repo.save(p));
		} catch (Exception ex) {
			log.error("Exception in save", ex);
			return Optional.empty();
		}
	}

	@Override
	public Optional<ProductEntity> addTopping(UUID productId, ProductEntity top) {
		try {
			var p = repo.findById(productId).orElseThrow(() -> new Exception("Prodotto non trovato"));
			if (!p.getClass().equals(FoodEntity.class))
				throw new Exception("Azione impossibile");
			var f = (FoodEntity) p;
			var t = repo.findById(top.getId()).orElse(repo.save(top));
			f.getToppings().add((FoodEntity) t);
			return Optional.of(repo.save(f));
		} catch (Exception e) {
			log.error("Exception in addTopping", e);
		}
		return Optional.empty();
	}

	@Override
	public List<ProductEntity> list() {
		return repo.findAll();
	}

	@Override
	public List<FoodEntity> listFoods() {
		return repo.findAllByType(FoodEntity.ENTITY_TYPE).stream() //
				.map(f -> (FoodEntity) f).collect(Collectors.toList());
	}

	@Autowired
	EntityManager em;

	@Override
	public List<BeverageEntity> listBeverages(String name) {
		var cb = em.getCriteriaBuilder();
		var q = cb.createQuery(BeverageEntity.class);

		var root = q.from(BeverageEntity.class);
		if (name != null)
			q.where(cb.like(root.get("name"), "%" + name + "%"));

		return em.createQuery(q).getResultList();
	}

}
