package info.ennerre.pizzeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzeriaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzeriaSpringApplication.class, args);
	}

}
