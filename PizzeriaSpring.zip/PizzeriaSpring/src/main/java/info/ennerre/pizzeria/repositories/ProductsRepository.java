package info.ennerre.pizzeria.repositories;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import info.ennerre.pizzeria.entities.ProductEntity;

public interface ProductsRepository extends JpaRepository<ProductEntity, UUID> {

	List<ProductEntity> findAllByType(int type);
	
	
}
