package info.ennerre.pizzeria.entities;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "type", //
		discriminatorType = DiscriminatorType.INTEGER)
@Table(name = "products")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class ProductEntity extends BaseEntity {
	@Column(insertable = false, updatable = false)
	private int type;
	@Column(columnDefinition = "VARCHAR(50)", nullable = false)
	private String name;
	@Column(columnDefinition = "VARCHAR(255)", nullable = true)
	private String description;
}
