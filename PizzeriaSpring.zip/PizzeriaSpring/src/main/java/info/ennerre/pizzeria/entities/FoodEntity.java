package info.ennerre.pizzeria.entities;

import java.util.Set;
import java.util.HashSet;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@DiscriminatorValue(value = FoodEntity.TYPE)
@ToString(callSuper = true)
public class FoodEntity extends ProductEntity {
	private static final String TYPE = "2";
	public static final int ENTITY_TYPE = 2;
	private double weigth;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "toppings", //
			joinColumns = @JoinColumn(name = "food_fk"), //
			inverseJoinColumns = @JoinColumn(name = "topping_fk"))
	private final Set<FoodEntity> toppings = new HashSet<>();

	@Builder(setterPrefix = "with")
	public FoodEntity(String name, String description, double weight) {
		super(ENTITY_TYPE, name, description);
		this.weigth = weight;
	}

}
