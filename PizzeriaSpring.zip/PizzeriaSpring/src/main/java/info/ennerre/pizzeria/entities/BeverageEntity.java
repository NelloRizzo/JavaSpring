package info.ennerre.pizzeria.entities;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@DiscriminatorValue(BeverageEntity.TYPE)
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ToString(callSuper = true)
public class BeverageEntity extends ProductEntity {
	private static final String TYPE = "1";
	public static final int ENTITY_TYPE = 1;
	private int size;
	private String unit;

	@Builder(setterPrefix = "with")
	public BeverageEntity(String name, String description, int size, String unit) {
		super(ENTITY_TYPE, name, description);
		this.size = size;
		this.unit = unit;
	}
}
