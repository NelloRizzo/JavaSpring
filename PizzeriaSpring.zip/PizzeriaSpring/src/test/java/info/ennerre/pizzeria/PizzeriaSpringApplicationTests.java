package info.ennerre.pizzeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzeriaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
