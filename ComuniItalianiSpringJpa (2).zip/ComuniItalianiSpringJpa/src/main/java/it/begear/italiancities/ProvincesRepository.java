package it.begear.italiancities;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProvincesRepository extends JpaRepository<Province, Integer> {

}
