package it.begear.italiancities;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CitiesRepository extends JpaRepository<City, Integer>{

	List<City> findAllByProvinceAcronym(String acronym);

}
