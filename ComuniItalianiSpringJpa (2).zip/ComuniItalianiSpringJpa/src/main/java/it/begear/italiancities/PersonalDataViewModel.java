package it.begear.italiancities;

import java.time.LocalDate;
import java.util.Optional;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonalDataViewModel {
	@NotNull(message = "Inserire il nome")
	@Size(min = 1, max = 20, message = "Inserire un nome composto al più da 20 caratteri")
	private String firstName;
	@NotNull(message = "Inserire il cognome")
	@Size(max = 20, message = "Cognome troppo lungo (max 20 caratteri)")
	private String lastName;
	@NotNull(message = "Inserire la data di nascita")
	private LocalDate birthday;
	private Optional<String> birthCityAcronym;
	@Min(1)
	private int birthCity;
	private boolean male = true;
}
