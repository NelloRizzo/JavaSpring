package it.begear.italiancities;

public interface FiscalCodeService {
	public String getFiscalCode(PersonalDataViewModel data);
}
