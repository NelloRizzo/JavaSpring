package it.begear.italiancities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/cities")
public class CitiesController {

	@Autowired
	ProvincesRepository provinces;
	@Autowired
	CitiesRepository cities;

	@GetMapping()
	public ModelAndView listProvinces(Model model) {
		model.addAttribute("prov", provinces.findAll().stream().sorted());
		return new ModelAndView("cities", model.asMap());
	}

	@GetMapping("{acronym}")
	public String listCities(Model model, @PathVariable String acronym) {
		model.addAttribute("selected", acronym);
		model.addAttribute("prov", provinces.findAll().stream().sorted());
		model.addAttribute("cities", cities.findAllByProvinceAcronym(acronym).stream().sorted());
		return "cities";
	}
}
