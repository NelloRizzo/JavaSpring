package it.begear.italiancities;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/")
public class FiscalCodeController {
	private static Logger logger = LoggerFactory.getLogger(FiscalCodeController.class);

	@Autowired
	FiscalCodeService service;
	@Autowired
	CitiesRepository repo;

	@GetMapping
	public ModelAndView dataInput(PersonalDataViewModel data) {
		data.setBirthCityAcronym(Optional.of("AG"));
		return new ModelAndView("index", "data", data);
	}

	@PostMapping("/calculateFiscalCode")
	public String calculateFiscalCode(@Valid @ModelAttribute("data") PersonalDataViewModel data, //
			BindingResult validation, Model model) {

		if (validation.hasErrors()) {
			logger.debug("{}", validation.getAllErrors());
			return "index";
		}

		model.addAttribute("data", data);
		model.addAttribute("city", repo.findById(data.getBirthCity()));
		model.addAttribute("fiscalCode", service.getFiscalCode(data));
		logger.debug("Fiscal code for {} is {}", data, model.getAttribute("fiscalCode"));
		return "fc";
	}
}
