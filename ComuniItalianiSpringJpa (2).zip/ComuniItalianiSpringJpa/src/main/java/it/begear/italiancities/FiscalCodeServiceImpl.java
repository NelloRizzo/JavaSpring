package it.begear.italiancities;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FiscalCodeServiceImpl implements FiscalCodeService {

	@Autowired
	CitiesRepository cities;

	@Override
	public String getFiscalCode(PersonalDataViewModel data) {
		var sb = new StringBuilder(16) //
				.append(handleLastName(data.getLastName())) //
				.append(handleFirstName(data.getFirstName())) //
				.append(handleBirthday(data.getBirthday(), data.isMale())) //
				.append(handleBirthCity(data.getBirthCity()));
		return sb.append(calcCheckCode(sb)).toString();
	}

	private char calcCheckCode(StringBuilder sb) {
		int[] odds = { 1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23 };
		int sum = 0;
		for (var i = 0; i < 15; ++i) {
			var c = sb.charAt(i);
			var depl = Character.isDigit(c) ? c - '0' : c - 'A';
			sum += (i % 2 == 0) ? odds[depl] : depl;
		}
		return (char) (sum % 26 + 'A');
	}

	private String handleBirthCity(int birthCity) {
		var c = cities.findById(birthCity);
		return c.isEmpty() ? "X000" : c.get().getCadastralCode();
	}

	private String handleBirthday(LocalDate birthday, boolean male) {
		var months = "ABCDEHLMPRST";
		return String.format("%1$ty%2$c%3$02d", //
				birthday, //
				months.charAt(birthday.getMonthValue() - 1), //
				birthday.getDayOfMonth() + (male ? 0 : 40));
	}

	private static class ConsonantsVowels {
		public final StringBuilder consonants = new StringBuilder();
		public final StringBuilder vowels = new StringBuilder();

		public ConsonantsVowels(String text) {
			text.toUpperCase().chars() //
					.filter(Character::isAlphabetic) //
					.forEach(c -> {
						if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
							vowels.append((char) c);
						else
							consonants.append((char) c);
					});
			;
		}
	}

	private String handleFirstName(String firstName) {
		var cv = new ConsonantsVowels(firstName);
		if (cv.consonants.length() > 3)
			cv.consonants.delete(1, 2);
		return cv.consonants.append(cv.vowels.append("XXX")).substring(0, 3);
	}

	private String handleLastName(String lastName) {
		var cv = new ConsonantsVowels(lastName);
		return cv.consonants.append(cv.vowels.append("XXX")).substring(0, 3);
	}

}
