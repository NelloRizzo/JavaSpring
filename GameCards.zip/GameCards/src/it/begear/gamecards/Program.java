package it.begear.gamecards;

import it.begear.gamecards.logic.cards.Card;
import it.begear.gamecards.logic.decks.Deck;
import it.begear.gamecards.logic.decks.FrenchDeck;
import it.begear.gamecards.logic.decks.NeapoleanDeck;

public class Program {

	public static void deal(Deck<? extends Card<? extends Enum<?>>> deck, boolean shuffle) {
		System.out.println("Distribuisco " + deck.getClass().getSimpleName());
		if (shuffle) {
			System.out.println("Mescolo il mazzo di carte");
			deck.shuffle();
		}
		var count = 0;
		for (var c : deck) {
			System.out.format("%02d\t%s\n", ++count, c);
		}
	}

	public static void main(String[] args) {
		var nd = new NeapoleanDeck();
		deal(nd, false);
		var fd = new FrenchDeck();
		deal(fd, false);
		deal(fd, true);
	}

}
