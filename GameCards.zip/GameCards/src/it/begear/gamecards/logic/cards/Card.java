package it.begear.gamecards.logic.cards;

import java.util.Objects;

public abstract class Card<E extends Enum<E>> {
	public abstract E getSeed();

	private final int seed;
	private final int value;

	public int getSeedAsInt() {
		return seed;
	}

	public int getValue() {
		return value;
	}

	protected Card(int seed, int value) {
		this.seed = seed;
		this.value = value;
	}

	@Override
	public boolean equals(Object obj) {
		return obj != null && obj.getClass().equals(getClass()) && obj.hashCode() == hashCode();
	}

	@Override
	public int hashCode() {
		return Objects.hash(seed, value);
	}
}
