package it.begear.gamecards.logic.cards;

import it.begear.gamecards.logic.exceptions.InvalidValueException;

public class FrenchCard extends Card<FrenchCard.Seed> {

	public enum Seed {
		Hearts, Diamonds, Clubs, Spades
	}

	public static final int JOKER_VALUE = -1;
	public static final Seed RED_JOKER_SEED = Seed.Hearts;
	public static final Seed BLACK_JOKER_SEED = Seed.Spades;

	public static final FrenchCard RED_JOKER = new FrenchCard(RED_JOKER_SEED, JOKER_VALUE);
	public static final FrenchCard BLACK_JOKER = new FrenchCard(BLACK_JOKER_SEED, JOKER_VALUE);

	@Override
	public Seed getSeed() {
		return Seed.values()[getSeedAsInt()];
	}

	protected FrenchCard(Seed seed, int value) {
		super(seed.ordinal(), value);
	}

	@Override
	public String toString() {
		var v = getValue();
		var s = getSeed();
		if (v == JOKER_VALUE)
			return s == RED_JOKER_SEED ? "Red Joker" : "Black Joker";
		String[] values = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
		return String.format("%s of %s", values[v - 1], s);
	}

	public static class Builder {
		private Seed seed;
		private int value;

		public Builder withSeed(Seed seed) {
			this.seed = seed;
			return this;
		}

		public Builder withValue(int value) {
			this.value = value;
			return this;
		}

		public FrenchCard build() {
			if (value < 1 || value > 13)
				throw new InvalidValueException(value);
			return new FrenchCard(seed, value);
		}
	}
}
