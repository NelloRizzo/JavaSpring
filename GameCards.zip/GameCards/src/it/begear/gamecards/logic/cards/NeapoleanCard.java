package it.begear.gamecards.logic.cards;

import it.begear.gamecards.logic.exceptions.InvalidValueException;

public class NeapoleanCard extends Card<NeapoleanCard.Seed> {
	public enum Seed {
		Denari, Coppe, Spade, Bastoni
	}

	@Override
	public Seed getSeed() {
		return Seed.values()[getSeedAsInt()];
	}

	protected NeapoleanCard(Seed seed, int value) {
		super(seed.ordinal(), value);
	}

	@Override
	public String toString() {
		var v = getValue();
		var s = getSeed();
		if (v == 7 && s == Seed.Denari)
			return "settebello";
		String[] values = { "asso", "2", "3", "4", "5", "6", "7", "donna", "cavallo", "re" };
		return String.format("%s di %s", values[v - 1], s).toLowerCase();
	}

	public static class Builder {
		private Seed seed;
		private int value;

		public Builder withSeed(Seed seed) {
			this.seed = seed;
			return this;
		}

		public Builder withValue(int value) {
			this.value = value;
			return this;
		}

		public NeapoleanCard build() {
			if (value < 1 || value > 10)
				throw new InvalidValueException(value);
			return new NeapoleanCard(seed, value);
		}
	}
}
