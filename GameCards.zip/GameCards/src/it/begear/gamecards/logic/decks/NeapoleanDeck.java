package it.begear.gamecards.logic.decks;

import it.begear.gamecards.logic.cards.NeapoleanCard;
import it.begear.gamecards.logic.cards.NeapoleanCard.Seed;

public class NeapoleanDeck extends Deck<NeapoleanCard> {

	public NeapoleanDeck() {
		super(40);
		var builder = new NeapoleanCard.Builder();
		for (var s = 0; s < 4; ++s) {
			for (var v = 1; v < 11; ++v) {
				cards.add(builder.withSeed(Seed.values()[s]).withValue(v).build());
			}
		}
	}

}
