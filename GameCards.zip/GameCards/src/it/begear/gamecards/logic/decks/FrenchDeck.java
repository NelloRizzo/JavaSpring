package it.begear.gamecards.logic.decks;

import it.begear.gamecards.logic.cards.FrenchCard;
import it.begear.gamecards.logic.cards.FrenchCard.Seed;

public class FrenchDeck extends Deck<FrenchCard> {

	public FrenchDeck() {
		super(54);
		var builder = new FrenchCard.Builder();
		for (var s = 0; s < 4; ++s) {
			for (var v = 1; v < 14; ++v) {
				cards.add(builder.withSeed(Seed.values()[s]).withValue(v).build());
			}
		}
		cards.add(FrenchCard.BLACK_JOKER);
		cards.add(FrenchCard.RED_JOKER);
	}

}
