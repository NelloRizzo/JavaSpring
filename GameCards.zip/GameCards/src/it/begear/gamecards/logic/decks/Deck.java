package it.begear.gamecards.logic.decks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import it.begear.gamecards.logic.cards.Card;

public class Deck<C extends Card<? extends Enum<?>>> implements Iterable<C> {
	protected final List<C> cards;
	private final int totalCards;

	public int getTotalCards() {
		return totalCards;
	}

	protected Deck(int totalCards) {
		this.totalCards = totalCards;
		cards = new ArrayList<>(totalCards);
	}

	public void shuffle() {
		Collections.shuffle(cards);
	}

	@Override
	public Iterator<C> iterator() {
		return cards.iterator();
	}
}
