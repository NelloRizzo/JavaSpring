package it.begear.gamecards.logic.exceptions;

public class InvalidValueException extends CardException {
	private static final long serialVersionUID = 1L;

	private final int invalidValue;

	public InvalidValueException(int value) {
		invalidValue = value;
	}

	public int getInvalidValue() {
		return invalidValue;
	}
}
