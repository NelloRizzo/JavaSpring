package it.begear.gamecards.logic.exceptions;

public class CardException extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
