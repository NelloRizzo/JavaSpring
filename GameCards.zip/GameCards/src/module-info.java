/**
 * 
 */
/**
 * @author Utente
 *
 */
module GameCards {
}