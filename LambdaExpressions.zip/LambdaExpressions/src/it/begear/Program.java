package it.begear;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Stream;

public class Program {

	public static void sortAsc(int[] a) {
		for (var i = 0; i < a.length - 1; ++i) {
			for (var j = i + 1; j < a.length; ++j) {
				if (a[i] > a[j]) {
					var t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
			}
		}
	}

	public static void sortDesc(int[] a) {
		for (var i = 0; i < a.length - 1; ++i) {
			for (var j = i + 1; j < a.length; ++j) {
				if (a[i] < a[j]) {
					var t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
			}
		}
	}

	public static void sortWithCheck(int[] a) {
		for (var i = 0; i < a.length - 1; ++i) {
			for (var j = i + 1; j < a.length; ++j) {
				if (CheckIfSwapForDesc(a[i], a[j])) {
					var t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
			}
		}
	}

	public static boolean CheckIfSwapForAsc(int a, int b) {
		return a > b;
	}

	public static boolean CheckIfSwapForDesc(int a, int b) {
		return a < b;
	}

	public interface Swapper {
		public boolean checkIfSwap(int a, int b);
	}

	public static class AscSwapper implements Swapper {

		@Override
		public boolean checkIfSwap(int a, int b) {
			return a > b;
		}

	}

	public static class DescSwapper implements Swapper {

		@Override
		public boolean checkIfSwap(int a, int b) {
			return a < b;
		}

	}

	public static void sortWithFunc(int[] a, Swapper f) {
		for (var i = 0; i < a.length - 1; ++i) {
			for (var j = i + 1; j < a.length; ++j) {
				if (f.checkIfSwap(a[i], a[j])) {
					var t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
			}
		}
	}

	public static void print(int[] a) {
		for (var i : a)
			System.out.println(i);
	}

	public static void main(String[] args) {
		int[] numbers = { 21, 25, 46, 724687, 9476, 7364, 6589, 7254, 790, 8967, 4878 };
		System.out.println("Array da ordinare:");
		print(numbers);
		sortAsc(numbers);
		System.out.println("Array ordinato in senso crescente:");
		print(numbers);
		sortDesc(numbers);
		System.out.println("Array ordinato in senso decrescente:");
		print(numbers);
		sortWithCheck(numbers);
		System.out.println("Array ordinato con funzione esterna:");
		print(numbers);
		sortWithFunc(numbers, new AscSwapper());
		System.out.println("Array ordinato con funzione AscSwapper:");
		print(numbers);
		sortWithFunc(numbers, new DescSwapper());
		System.out.println("Array ordinato con funzione DescSwapper:");
		print(numbers);
		sortWithFunc(numbers, new Swapper() {

			@Override
			public boolean checkIfSwap(int a, int b) {
				return a > b;
			}
		});
		System.out.println("Array ordinato con classe anonima:");
		print(numbers);
		sortWithFunc(numbers, (int a, int b) -> a > b);
		System.out.println("Array ordinato con lambda:");
		print(numbers);

		var list = new ArrayList<Integer>(Arrays.asList(23, 234, 3657, 869, 236, 4689, 690, 6980));
		Stream<?> str = list.stream().filter(x -> x % 2 == 0);
		str = str.map(x -> String.format("Numero: %d", x)); 
		
		list.add(1234);
		list.add(1235);
		list.add(1236);
		str.forEach(System.out::println);
	}
}
