/**
 * 
 */
/**
 * @author Utente
 *
 */
module LambdaExpressions {
}