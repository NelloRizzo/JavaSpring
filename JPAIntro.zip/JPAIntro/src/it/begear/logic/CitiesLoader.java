package it.begear.logic;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

import it.begear.entities.Area;
import it.begear.entities.City;
import it.begear.entities.Province;
import it.begear.entities.Region;

public class CitiesLoader {

	private static final int REGION_CODE = 0;
	private static final int PROVINCE_CODE = 2;
	private static final int CITY_CODE = 4;
	private static final int CITY_NAME = 6;
	private static final int AREA_CODE = 8;
	private static final int AREA_NAME = 9;
	private static final int REGION_NAME = 10;
	private static final int PROVINCE_NAME = 11;
	private static final int CITY_CAPITAL = 13;
	private static final int PROVINCE_ACRONYM = 14;
	private static final int CITY_CADASTRAL = 19;

	public static Set<City> load(String fileName) {
		var result = new HashSet<City>();
		try {
			Files.readAllLines(Paths.get(fileName), StandardCharsets.ISO_8859_1) //
					.stream() //
					.skip(3) //
					.forEach(l -> {
						var p = l.split(";");
						var city = new City( //
								Integer.parseInt(p[CITY_CODE]), //
								p[CITY_NAME], //
								new Province( //
										Integer.parseInt(p[PROVINCE_CODE]), //
										p[PROVINCE_NAME], //
										p[PROVINCE_ACRONYM], //
										new Region( //
												Integer.parseInt(p[REGION_CODE]), //
												p[REGION_NAME], //
												new Area( //
														Integer.parseInt(p[AREA_CODE]), //
														p[AREA_NAME]))),
								p[CITY_CADASTRAL], //
								p[CITY_CAPITAL].charAt(0) == '1');
						result.add(city);
					});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}
}
