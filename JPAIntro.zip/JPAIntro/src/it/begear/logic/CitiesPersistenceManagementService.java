package it.begear.logic;

import it.begear.entities.City;
import it.begear.entities.Province;

public interface CitiesPersistenceManagementService {
	public void save(Iterable<City> cities);
	public Iterable<City> getCitiesByProvinceAcronym(String acronym);
	public Iterable<Province> getProvinces();
}
