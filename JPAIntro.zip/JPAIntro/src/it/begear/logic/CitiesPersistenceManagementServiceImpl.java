package it.begear.logic;

import java.util.ArrayList;
import java.util.stream.StreamSupport;

import it.begear.entities.City;
import it.begear.entities.Province;
import it.begear.entities.Region;
import it.begear.entities.Area;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CitiesPersistenceManagementServiceImpl implements CitiesPersistenceManagementService {

	private final EntityManagerFactory emf;

	public CitiesPersistenceManagementServiceImpl(String pu) {
		emf = Persistence.createEntityManagerFactory(pu);
	}

	@Override
	public void save(Iterable<City> cities) {
		try {
			var em = emf.createEntityManager();
			em.getTransaction().begin();
			// salvo le ripartizioni
			StreamSupport.stream(cities.spliterator(), false).map(c -> c.getProvince().getRegion().getArea()).distinct() //
					.forEach(a -> {
						em.persist(a);
					});
			// salvo le regioni
			StreamSupport.stream(cities.spliterator(), false).map(c -> c.getProvince().getRegion()) //
					.distinct() //
					.forEach(r -> {
						r.setArea(em.find(Area.class, r.getArea().getId()));
						em.persist(r);
					});
			;
			// salvo le province
			StreamSupport.stream(cities.spliterator(), false).map(c -> c.getProvince()).distinct() //
					.forEach(p -> {
						p.setRegion(em.find(Region.class, p.getRegion().getId()));
						em.persist(p);
					});
			;
			// salvo le città
			cities.forEach(c -> {
				c.setProvince(em.find(Province.class, c.getProvince().getId()));
				em.persist(c);
			});
			em.getTransaction().commit();
			em.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private static final String selectCities = //
			"SELECT c FROM City c WHERE c.province.acronym = :acronym ORDER BY c.name";

	@Override
	public Iterable<City> getCitiesByProvinceAcronym(String acronym) {
		var result = new ArrayList<City>();
		try {
			var em = emf.createEntityManager();
			var q = em.createQuery(selectCities, City.class);
			q.setParameter("acronym", acronym);
			result.addAll(q.getResultList());
			em.close();
		} catch (Exception ex) {

		}
		return result;
	}

	private static final String selectProvinces = //
			"SELECT p FROM Province p ORDER BY p.name";

	@Override
	public Iterable<Province> getProvinces() {
		var result = new ArrayList<Province>();
		try {
			var em = emf.createEntityManager();
			var q = em.createQuery(selectProvinces, Province.class);
			result.addAll(q.getResultList());
			em.close();
		} catch (Exception ex) {

		}
		return result;
	}

}
