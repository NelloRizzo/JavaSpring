package it.begear.entities;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cities")
public class City {
	private int id;
	private String name;
	private Province province;
	private String cadastralCode;
	private boolean capital;

	public City(int id, String name, Province province, String cadastralCode, boolean capital) {
		this.id = id;
		this.name = name;
		this.province = province;
		this.cadastralCode = cadastralCode;
		this.capital = capital;
	}

	public City() {
	}

	@Id
	public int getId() {
		return id;
	}

	@Column(name = "name", columnDefinition = "VARCHAR(80)", nullable = false)
	public String getName() {
		return name;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	public Province getProvince() {
		return province;
	}

	@Column(name = "code", columnDefinition = "CHAR(4)", nullable = false)
	public String getCadastralCode() {
		return cadastralCode;
	}

	public boolean isCapital() {
		return capital;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setProvince(Province province) {
		this.province = province;
	}

	public void setCadastralCode(String cadastralCode) {
		this.cadastralCode = cadastralCode;
	}

	public void setCapital(boolean capital) {
		this.capital = capital;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		return id == other.id;
	}

	@Override
	public String toString() {
		return "City [id=" + id + ", name=" + name + ", province=" + province + ", cadastralCode=" + cadastralCode
				+ ", capital=" + capital + "]";
	}
}
