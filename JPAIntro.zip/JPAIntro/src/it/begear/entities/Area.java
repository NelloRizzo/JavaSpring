package it.begear.entities;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="areas")
public class Area {
	private int id;
	private String name;

	public Area(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public Area() {
	}

	@Id
	public int getId() {
		return id;
	}

	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	public String getName() {
		return name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Area other = (Area) obj;
		return id == other.id;
	}

	@Override
	public String toString() {
		return "Area [id=" + id + ", name=" + name + "]";
	}

}
