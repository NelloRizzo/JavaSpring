package it.begear.entities;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "regions")
public class Region {
	private int id;
	private String name;
	private Area area;

	public Region(int id, String name, Area area) {
		this.id = id;
		this.name = name;
		this.area = area;
	}

	public Region() {
	}

	@Id
	public int getId() {
		return id;
	}

	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	public String getName() {
		return name;
	}

	@ManyToOne
	public Area getArea() {
		return area;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Region other = (Region) obj;
		return id == other.id;
	}

	@Override
	public String toString() {
		return "Region [id=" + id + ", name=" + name + ", area=" + area + "]";
	}

}
