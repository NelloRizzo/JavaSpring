package it.begear;

import it.begear.entities.City;
import it.begear.logic.CitiesLoader;
import it.begear.logic.CitiesPersistenceManagementService;
import it.begear.logic.CitiesPersistenceManagementServiceImpl;

public class Program {

	private static final String PU_NAME = "JPAIntro";

	public static void persistCities(Iterable<City> cities) {
		CitiesPersistenceManagementService service = //
				new CitiesPersistenceManagementServiceImpl(PU_NAME);
		service.save(cities);

		System.out.println("Province recuperate dal database");
		service.getProvinces().forEach(System.out::println);

		System.out.println("Città in provincia di Roma:");
		// service.getCitiesByProvinceAcronym("RM").forEach(c ->
		// System.out.println(c.getName()));
		service.getCitiesByProvinceAcronym("RM").forEach(System.out::println);
	}

	public static void main(String[] args) {
		var cities = CitiesLoader.load("comuni.csv");

		System.out.println("Caricate " + cities.size() + " città");

		cities.stream().map(c -> c.getProvince()).distinct() //
				.forEach(System.out::println);
		cities.stream().filter(c -> c.getProvince().getAcronym().equals("RM"))//
				.forEach(System.out::println);

		persistCities(cities);
	}

}
