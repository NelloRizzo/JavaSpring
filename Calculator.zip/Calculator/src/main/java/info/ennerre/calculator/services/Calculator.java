package info.ennerre.calculator.services;

import java.math.BigDecimal;

public interface Calculator {
	public BigDecimal getAccumulator();

	public void execute(char operation, BigDecimal operand);
}
