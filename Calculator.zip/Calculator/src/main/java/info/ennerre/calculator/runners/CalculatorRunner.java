package info.ennerre.calculator.runners;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import info.ennerre.calculator.services.Calculator;

@Component
public class CalculatorRunner implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(CalculatorRunner.class);
	
	@Autowired
	Calculator calculator;
	
	@Override
	public void run(String... args) throws Exception {
		calculator.execute('=', BigDecimal.valueOf(1230));
		calculator.execute('+', BigDecimal.valueOf(212340));
		calculator.execute('-', BigDecimal.valueOf(32430));
		calculator.execute('*', BigDecimal.valueOf(43240));
		calculator.execute('/', BigDecimal.valueOf(13545));
		
		log.info("Accumulator = {}", calculator.getAccumulator());
	}

}
