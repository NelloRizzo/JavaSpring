package info.ennerre.calculator.services;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

@Service
public class CalculatorImpl implements Calculator {
	private BigDecimal accumulator = BigDecimal.ZERO;

	@Override
	public BigDecimal getAccumulator() {
		return accumulator;
	}

	@Override
	public void execute(char operation, BigDecimal operand) {
		var a = accumulator.doubleValue();
		var b = operand.doubleValue();
		switch (operation) {
		case '+':
			a += b;
			break;
		case '-':
			a -= b;
			break;
		case '*':
			a *= b;
			break;
		case '/':
			a /= b;
			break;
		default:
			a = b;
		}
		accumulator = BigDecimal.valueOf(a);
	}

}
