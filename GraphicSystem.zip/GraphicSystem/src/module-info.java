/**
 * 
 */
/**
 * @author Utente
 *
 */
module GraphicSystem {
	requires java.desktop;
}