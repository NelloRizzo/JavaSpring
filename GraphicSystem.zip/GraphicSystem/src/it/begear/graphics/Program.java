package it.begear.graphics;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import it.begear.graphics.models.Circle;
import it.begear.graphics.models.Ellipse;
import it.begear.graphics.models.Point;
import it.begear.graphics.models.Rectangle;
import it.begear.graphics.models.Shape;
import it.begear.graphics.models.Square;
import it.begear.graphics.models.canvas.BitmapCanvas;
import it.begear.graphics.models.canvas.Canvas;
import it.begear.graphics.models.canvas.CharCanvas;

public class Program {

	public static void drawLines(Canvas c) {
		c.line(new Point(0, 0), new Point(79, 22));
		c.line(new Point(0, 22), new Point(79, 0));
	}

	public static void drawShapes(List<? extends Shape> s, Canvas c) {
		for (var shape : s)
			shape.draw(c);
	}

	public static void main(String[] args) {
		var c = new CharCanvas(80, 23);
		c.setCurrentFill('.');
		drawLines(c);
		c.print(System.out);
		c.clear();
		var s = Arrays.asList(new Rectangle(10, 10, 50, 20), //new Square(10, 10, 5), new Ellipse(10, 10, 50, 20),
				new Circle(15, 15, 7));
		drawShapes(s, c);
		c.print(System.out);

		var i = new BitmapCanvas(80, 23);
		i.setColor(Color.red);
		drawShapes(s, i);
		i.save("test.jpg");
	}

}
