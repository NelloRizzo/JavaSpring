package it.begear.graphics.models.canvas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import it.begear.graphics.models.Point;

public class BitmapCanvas implements Canvas {

	private final BufferedImage image;
	private final Graphics graphics;
	private final int width;
	private final int height;
	private Color color = Color.BLACK;

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public static class ImagePoint extends Point {

		private int rgb;

		public int getRgb() {
			return rgb;
		}

		public ImagePoint(double x, double y, int rgb) {
			super(x, y);
			this.rgb = rgb;
		}

	}

	public BitmapCanvas(int width, int height) {
		this.width = width;
		this.height = height;
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		graphics = image.getGraphics();
		clear();
	}

	@Override
	public Point get(double x, double y) {
		var p = image.getRGB((int) x, (int) y);
		return new ImagePoint(x, y, p);
	}

	@Override
	public void clear() {
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, width, height);
	}

	@Override
	public void set(double x, double y) {
		image.setRGB((int) x, (int) y, color.getRGB());
	}

	@Override
	public void reset(double x, double y) {
		image.setRGB((int) x, (int) y, 0);
	}

	@Override
	public void line(Point from, Point to) {
		graphics.setColor(color);
		graphics.drawLine((int) from.getX(), (int) from.getY(), (int) to.getX(), (int) to.getY());
	}

	public void save(String filename) {
		try {
			ImageIO.write(image, "jpg", new File(filename));
			System.out.println("Immagine salvata su " + filename);
		} catch (IOException e) {
			System.err.println(e);
		}
	}
}
