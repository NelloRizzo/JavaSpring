package it.begear.graphics.models.canvas;

import java.io.PrintStream;

import it.begear.graphics.models.Point;

public class CharCanvas implements Canvas {
	public static final char EMPTY = ' ';
	public static final char FILLED = '*';

	public static class CharCanvasPoint extends Point {
		private char symbol;

		public CharCanvasPoint() {
			this(0, 0, EMPTY);
		}

		public CharCanvasPoint(double x, double y) {
			this(x, y, EMPTY);
		}

		public CharCanvasPoint(double x, double y, char symbol) {
			super(x, y);
			this.symbol = symbol;
		}

		public char getSymbol() {
			return symbol;
		}

		public void setSymbol(char symbol) {
			this.symbol = symbol;
		}
	}

	private final CharCanvasPoint[][] points;
	private char currentFill;
	private final int width;
	private final int height;

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public char getCurrentFill() {
		return currentFill;
	}

	public void setCurrentFill(char currentFill) {
		this.currentFill = currentFill;
	}

	public CharCanvas(int width, int height) {
		currentFill = FILLED;
		this.width = width;
		this.height = height;
		points = new CharCanvasPoint[height][];
		clear();
	}

	@Override
	public Point get(double x, double y) {
		return points[(int) y][(int) x];
	}

	@Override
	public void set(double x, double y) {
		set(x, y, currentFill);
	}

	@Override
	public void reset(double x, double y) {
		set(x, y, EMPTY);
	}

	private void set(double x, double y, char filler) {
		var r = (int) y;
		var c = (int) x;
		points[r][c].setSymbol(filler);
	}

	@Override
	public void line(Point from, Point to) {
		if (from.getX() == to.getX()) {
			var x = from.getX();
			var f = Math.min(from.getY(), to.getY());
			var t = Math.max(from.getY(), to.getY());
			set(to.getX(), to.getY());
			set(from.getX(), from.getY());
			for (var y = f; y <= t; y += .1) {
				set(x, y);
			}
		} else {
			var x1 = from.getX();
			var x2 = to.getX();
			var y1 = from.getY();
			var y2 = to.getY();

			var m = (y1 - y2) / (x1 - x2);
			var q = (x1 * y2 - x2 * y1) / (x1 - x2);

			var f = Math.min(x1, x2);
			var t = Math.max(x1, x2);
			for (var x = f; x < t; x += .1) {
				var y = m * x + q;
				set(x, y);
			}
		}
	}

	public void print(PrintStream s) {
		s.write(' ');
		for (var x = 0; x < width; ++x) {
			s.write(x % 10 + '0');
		}
		s.write('\n');
		for (var y = 0; y < height; ++y) {
			s.write(y % 10 + '0');
			for (var x = 0; x < width; ++x) {
				var p = (CharCanvasPoint) get(x, y);
				s.write(p.getSymbol());
			}
			s.write('\n');
		}
	}

	@Override
	public void clear() {
		for (var r = 0; r < height; ++r) {
			points[r] = new CharCanvasPoint[width];
			for (var c = 0; c < width; ++c) {
				points[r][c] = new CharCanvasPoint(c, r, EMPTY);
			}
		}
	}
}
