package it.begear.graphics.models.canvas;

import it.begear.graphics.models.Point;

public interface Canvas {
	public Point get(double x, double y);

	public void clear();

	public void set(double x, double y);

	public void reset(double x, double y);

	public void line(Point from, Point to);
}
