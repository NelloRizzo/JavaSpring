package it.begear.graphics.models.canvas;

public interface Drawable {
	public void draw(Canvas c);
}
