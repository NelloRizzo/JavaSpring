package it.begear.graphics.models;

import it.begear.graphics.models.canvas.Canvas;
import it.begear.graphics.models.canvas.Drawable;

public abstract class Shape implements Drawable {

	private Boundary boundary;

	@Override
	public abstract void draw(Canvas c);

	public Shape(double x1, double y1, double x2, double y2) {
		this(new Point(x1, y1), new Point(x2, y2));
	}

	public Shape(Point first, Point last) {
		this.boundary = new Boundary(first, last);
	}

	public Boundary getBoundary() {
		return boundary;
	}

	public void moveTo(double x, double y) {
		boundary.moveTo(x, y);
	}

	public void moveBy(double dx, double dy) {
		boundary.moveBy(dx, dy);
	}
}
