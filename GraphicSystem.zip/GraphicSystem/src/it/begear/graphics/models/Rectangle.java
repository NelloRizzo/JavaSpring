package it.begear.graphics.models;

import it.begear.graphics.models.canvas.Canvas;

public class Rectangle extends Shape {

	public Rectangle(double x1, double y1, double x2, double y2) {
		super(x1, y1, x2, y2);
	}

	public Rectangle(Point first, Point last) {
		super(first, last);
	}

	@Override
	public void draw(Canvas c) {
		c.line(getBoundary().getTopLeft(), getBoundary().getTopRight());
		c.line(getBoundary().getTopLeft(), getBoundary().getBottomLeft());
		c.line(getBoundary().getBottomLeft(), getBoundary().getBottomRight());
		c.line(getBoundary().getBottomRight(), getBoundary().getTopRight());
	}

}
