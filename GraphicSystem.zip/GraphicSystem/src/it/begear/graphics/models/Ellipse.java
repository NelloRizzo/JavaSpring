package it.begear.graphics.models;

import it.begear.graphics.models.canvas.Canvas;

public class Ellipse extends Shape {

	public Ellipse(double x1, double y1, double x2, double y2) {
		super(x1, y1, x2, y2);
	}

	public Ellipse(Point first, Point last) {
		super(first, last);
	}

	@Override
	public void draw(Canvas c) {
		var hr = getBoundary().getWidth() / 2;
		var vr = getBoundary().getHeight() / 2;
		var center = getBoundary().getTopLeft().offset(hr, vr);

		for (var a = 0f; a <= 6.3; a += .1) {
			c.set(center.getX() + hr * Math.cos(a), center.getY() + vr * Math.sin(a));
		}
	}

}
