package it.begear.graphics.models;

public class Circle extends Ellipse {

	public Circle(Point center, float radius) {
		super(center.offset(-radius, -radius), center.offset(radius, radius));
	}

	public Circle(double centerX, double centerY, float radius) {
		this(new Point(centerX, centerY), radius);
	}
}
