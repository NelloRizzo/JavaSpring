package it.begear.graphics.models;

public class Boundary {
	private Point first;
	private Point last;

	public Point getFirst() {
		try {
			return (Point) first.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	public Point getLast() {
		try {
			return (Point) last.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	public Point getTopLeft() {
		var x1 = Math.min(first.getX(), last.getX());
		Math.max(first.getX(), last.getX());
		var y1 = Math.min(first.getY(), last.getY());
		Math.max(first.getY(), last.getY());
		return new Point(x1, y1);
	}

	public Point getBottomLeft() {
		var x1 = Math.min(first.getX(), last.getX());
		Math.max(first.getX(), last.getX());
		Math.min(first.getY(), last.getY());
		var y2 = Math.max(first.getY(), last.getY());
		return new Point(x1, y2);
	}

	public Point getTopRight() {
		Math.min(first.getX(), last.getX());
		var x2 = Math.max(first.getX(), last.getX());
		var y1 = Math.min(first.getY(), last.getY());
		Math.max(first.getY(), last.getY());
		return new Point(x2, y1);
	}

	public Point getBottomRight() {
		Math.min(first.getX(), last.getX());
		var x2 = Math.max(first.getX(), last.getX());
		Math.min(first.getY(), last.getY());
		var y2 = Math.max(first.getY(), last.getY());
		return new Point(x2, y2);
	}

	public double getWidth() {
		return Math.abs(getTopRight().getX() - getTopLeft().getX());
	}

	public double getHeight() {
		return Math.abs(getBottomLeft().getY() - getTopLeft().getY());
	}

	public Boundary(double x1, double y1, double x2, double y2) {
		this(new Point(x1, y1), new Point(x2, y2));
	}

	public Boundary(Point first, Point last) {
		this.first = first;
		this.last = last;
	}

	public void moveTo(double x, double y) {
		var w = getWidth();
		var h = getHeight();
		first = new Point(x, y);
		last = new Point(x + w, y + h);
	}

	public void moveBy(double dx, double dy) {
		first.setX(first.getX() + dx);
		last.setX(last.getX() + dx);
		first.setY(first.getY() + dy);
		last.setY(last.getY() + dy);
	}

}
