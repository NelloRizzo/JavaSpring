package it.begear.graphics.models;

public class Square extends Rectangle {

	public Square(double x1, double y1, double side) {
		super(x1, y1, x1 + side, y1 + side);
	}

	public Square(Point first, double side) {
		super(first, first.offset(side, side));
	}

}
