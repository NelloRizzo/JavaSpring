package it.begear.graphics.models;

import java.util.Objects;

public class Point {
	private double x;
	private double y;

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public Point(double x, double y) {
		this();
		this.x = x;
		this.y = y;
	}

	public Point() {
		super();
	}

	public void moveTo(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public void moveBy(double dx, double dy) {
		this.x += dx;
		this.y += dy;
	}

	public Point offset(double dx, double dy) {
		return new Point(this.x + dx, y +dy);
	}

	public double dist(Point other) {
		var dx = x - other.x;
		var dy = y - other.y;
		return Math.sqrt(dx * dx + dy * dy);
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof Point && obj.hashCode() == hashCode();
	}

	@Override
	public int hashCode() {
		return Objects.hash(x, y);
	}

	@Override
	public String toString() {
		return String.format("Point(%02f,%02f)", x, y);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return new Point(x, y);
	}
}
