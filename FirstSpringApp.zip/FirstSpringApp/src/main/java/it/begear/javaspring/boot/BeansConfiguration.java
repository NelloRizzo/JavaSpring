package it.begear.javaspring.boot;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import it.begear.javaspring.boot.data.MyData;

@Configuration
public class BeansConfiguration {

	@Bean(name = "first")
	@Primary
	@Scope("prototype")
	MyData create() {
		var d = new MyData(10);
		return d;
	}

	@Bean(name = "second")
	MyData create2() {
		var d = new MyData(30);
		return d;
	}
}
