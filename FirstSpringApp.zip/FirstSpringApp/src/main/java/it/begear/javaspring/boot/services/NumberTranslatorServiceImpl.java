package it.begear.javaspring.boot.services;

import org.springframework.stereotype.Service;

@Service
public class NumberTranslatorServiceImpl implements NumberTranslatorService {

	@Override
	public String translate(int number) {
		if (number == 0)
			return "zero";
		if (number < 0)
			return "meno " + translateNumber(-number);
		return translateNumber(number);
	}

	private String translateNumber(int number) {
		if (number == 0)
			return "";
		if (number < 20) {
			var to20 = new String[] { "uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci",
					"undici", "dodici", "tredici", "quattordici", "quindici", "sedici", "diciassette", "diciotto",
					"diciannove" };
			return to20[number - 1];
		}
		if (number < 100) {
			var decs = new String[] { "venti", "trenta", "quaranta", "cinquanta", "sessanta", "settanta", "ottanta",
					"novanta" };
			return decs[number / 10 - 2] + translateNumber(number % 10);
		}
		if (number < 1000) {
			var h = number / 100;
			if (h == 1)
				return "cento" + translateNumber(number % 100);
			return translateNumber(h) + "cento" + translateNumber(number % 100);
		}
		if (number < 1000000) {
			var t = number / 1000;
			if (t == 1)
				return "mille" + translateNumber(number % 1000);
			return translateNumber(t) + "mila" + translateNumber(number % 1000);
		}
		if (number < 1000000000) {
			var m = number / 1000000;
			if (m == 1) return "unmilione" + translateNumber(number % 1000000);
			return translateNumber(m) + "milioni" + translateNumber(number % 1000000);
		}
		return "Overflow";
	}

}
