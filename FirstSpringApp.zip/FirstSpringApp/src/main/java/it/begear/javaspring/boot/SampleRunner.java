package it.begear.javaspring.boot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.begear.javaspring.boot.services.NumberTranslatorService;

@Component
public class SampleRunner implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(SampleRunner.class);

	@Autowired
	private NumberTranslatorService service;

	@Override
	public void run(String... args) throws Exception {
		for (var i = 999999; i < 1001000; i++)
			logger.debug("{}\t{}", i, service.translate(i));
	}
}
