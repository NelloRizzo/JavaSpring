package it.begear.javaspring.boot.services;

public interface NumberTranslatorService {
	public String translate(int number);
}
