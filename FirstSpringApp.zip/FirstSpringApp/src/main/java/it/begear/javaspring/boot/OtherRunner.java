package it.begear.javaspring.boot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.begear.javaspring.boot.data.MyData;

@Component
public class OtherRunner implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(OtherRunner.class);
	
	@Autowired
	private MyData data;

	@Override
	public void run(String... args) throws Exception {
		data.setValue(20);
		logger.debug("Il valore di data è {}", data);

	}

}
