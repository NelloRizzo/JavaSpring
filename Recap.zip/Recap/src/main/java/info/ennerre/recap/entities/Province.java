package info.ennerre.recap.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "provinces")
@Data
@NoArgsConstructor
public class Province {
	@Id
	private long id;
	@Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", insertable = false, updatable = false)
	private Date createdAt;
	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	private String name;
	@Column(columnDefinition = "CHAR(2)", nullable = false)
	private String acronym;

	@Builder(setterPrefix = "with")
	public Province(long id, Date createdAt, String name, String acronym) {
		this.id = id;
		this.createdAt = createdAt;
		this.name = name;
		this.acronym = acronym;
	}
}
