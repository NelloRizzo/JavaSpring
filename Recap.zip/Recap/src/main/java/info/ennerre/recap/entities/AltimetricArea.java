package info.ennerre.recap.entities;

import java.util.Arrays;

public enum AltimetricArea {
	NotSpecified(0), InlandMountain(1), CoastalMountain(2), InlandHill(3), CoastalHill(4), Pianura(5);

	public final int istatCode;

	private AltimetricArea(int istatCode) {
		this.istatCode = istatCode;
	}

	public static AltimetricArea fromInt(int value) {
		return Arrays.asList(values()).stream() //
				.filter(v -> v.istatCode == value) //
				.findAny().orElse(NotSpecified);
	}

}
