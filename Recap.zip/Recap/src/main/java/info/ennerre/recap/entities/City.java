package info.ennerre.recap.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cities")
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
public class City extends BaseEntity {
	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	private String name;
	private long province;
	private float area;
	private int people;
	@Enumerated(EnumType.ORDINAL)
	private AltimetricArea altimetric;
	private int altitude;
	private boolean coastal;
	private boolean island;
	@Enumerated(EnumType.ORDINAL)
	private UrbanisationDegree urbanisation;

	@Builder(setterPrefix = "with")
	public City(long id, Date createdAt, String name, long province, float area, int people,
			AltimetricArea altimetric, int altitude, boolean coastal, boolean island,
			UrbanisationDegree urbanisation) {
		super(id, createdAt);
		this.name = name;
		this.province = province;
		this.area = area;
		this.people = people;
		this.altimetric = altimetric;
		this.altitude = altitude;
		this.coastal = coastal;
		this.island = island;
		this.urbanisation = urbanisation;
	}

}
