package info.ennerre.recap.batches;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.ItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.transaction.PlatformTransactionManager;

import info.ennerre.recap.entities.AltimetricArea;
import info.ennerre.recap.entities.City;
import info.ennerre.recap.entities.Province;
import info.ennerre.recap.entities.UrbanisationDegree;
import info.ennerre.recap.repositories.ProvincesRespository;

@Configuration
public class BatchesConfiguration {

	private static final Logger log = LoggerFactory.getLogger(BatchesConfiguration.class);
	@Value("classpath:data/comuni.csv")
	Resource cities;

	@Value("classpath:data/stats.csv")
	Resource statistics;

	@Autowired
	ProvincesRespository provinces;

	@Bean
	FlatFileItemReader<Province> provincesReader() {
		return new FlatFileItemReaderBuilder<Province>() //
				.encoding(StandardCharsets.ISO_8859_1.name()) //
				.name("provincesReader").linesToSkip(3) //
				.lineMapper((line, number) -> {
					var fields = line.split(";");
					return Province.builder() //
							.withId(Integer.parseInt(fields[2])) //
							.withAcronym(fields[14]) //
							.withName(fields[11]) //
							.build();
				}) //
				.resource(cities) //
				.build();
	}

	@Bean
	FlatFileItemReader<City> citiesReader() {
		return new FlatFileItemReaderBuilder<City>() //
				.encoding(StandardCharsets.ISO_8859_1.name()) //
				.name("citiesReader").linesToSkip(3) //
				.lineMapper((l, n) -> {
					var f = l.split(";");
					return City.builder() //
							.withAltimetric(AltimetricArea.fromInt(Integer.parseInt(f[8]))) //
							.withAltitude(Integer.parseInt(f[9].replaceAll(".", ""))) //
							.withArea(Float.parseFloat(f[5].replace(",", "."))) //
							.withCoastal(f[10].charAt(0) == '1') //
							.withIsland(f[11].charAt(0) == '1') //
							.withName(f[3].trim()) //
							.withPeople(Integer.parseInt(f[7].replaceAll(".", ""))) //
							.withUrbanisation(UrbanisationDegree.fromInt(Integer.parseInt(f[13]))) //
							.withProvince(Integer.parseInt(f[1].substring(0, 3))) //
							.build();
				}) //
				.resource(statistics) //
				.build();
	}

	@Bean
	JdbcBatchItemWriter<City> cityWriter(DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<City>() //
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>()) //
				.sql("INSERT INTO cities(altimetric, altitude, area, coastal, island, name, people, province, urbanisation) "
						+ "VALUES(:altimetric, :altitude, :area, :coastal, :island, :name, :people, :province, :urbanisation)") //
				.itemSqlParameterSourceProvider(new ItemSqlParameterSourceProvider<City>() {

					@Override
					public SqlParameterSource createSqlParameterSource(City item) {
						var p = new HashMap<String, Object>();
						p.put("altimetric", item.getAltimetric().istatCode);
						p.put("altitude", item.getAltitude());
						p.put("area", item.getArea());
						p.put("coastal", item.isCoastal());
						p.put("island", item.isIsland());
						p.put("name", item.getName());
						p.put("province", item.getProvince());
						p.put("people", item.getPeople());
						p.put("urbanisation", item.getUrbanisation().value);
						return new MapSqlParameterSource(p);
					}
				}).dataSource(dataSource) //
				.build();
	}

	@Bean
	JdbcBatchItemWriter<Province> provincesWirter(DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<Province>() //
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>()) //
				.sql("INSERT INTO provinces(id, name, acronym) VALUES(:id, :name, :acronym)") //
				.dataSource(dataSource) //
				.build();
	}

	@Bean
	ItemProcessor<Province, Province> provinceProcessor() {
		return new ItemProcessor<Province, Province>() {
			@Override
			public Province process(Province item) throws Exception {
				if (provinces.findByName(item.getName()).isEmpty()) {
					log.debug("Processed {}", item);
					return item;
				}
				log.debug("Skipped {}", item);
				return null;
			}
		};
	}

	@Bean
	Step handleProvinces(JobRepository repo, //
			PlatformTransactionManager transactionManager, //
			JdbcBatchItemWriter<Province> writer) {
		return new StepBuilder("st_provinces", repo) //
				.<Province, Province>chunk(1000, transactionManager) //
				.reader(provincesReader()) //
				.processor(provinceProcessor()).writer(writer).build();
	}

	@Bean
	Step handleCities(JobRepository repo, //
			PlatformTransactionManager transactionManager, //
			JdbcBatchItemWriter<City> writer) {
		return new StepBuilder("st_cities", repo) //
				.<City, City>chunk(100, transactionManager) //
				.reader(citiesReader()) //
				.writer(writer).build();
	}

	@Bean
	Job importDataJob(JobRepository repo, JobCompletionNotificationListener listener, //
			Step handleProvinces, Step handleCities) {
		return new JobBuilder("importData", repo) //
				.listener(listener) //
				.flow(handleProvinces) //
				.next(handleCities) //
				.end() //
				.build();
	}

}
