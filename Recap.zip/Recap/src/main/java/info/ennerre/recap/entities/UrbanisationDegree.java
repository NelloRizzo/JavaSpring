package info.ennerre.recap.entities;

import java.util.Arrays;

public enum UrbanisationDegree {
	NotSpecified(0), City(1), SmallCity(2), Rural(3);

	public final int value;

	UrbanisationDegree(int value) {
		this.value = value;
	}

	public static UrbanisationDegree fromInt(int value) {
		return Arrays.asList(values()).stream() //
				.filter(v -> v.value == value) //
				.findAny().orElse(NotSpecified);
	}
}
