package info.ennerre.recap.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import info.ennerre.recap.entities.Province;

public interface ProvincesRespository extends JpaRepository<Province, Long> {

	Optional<Province> findByName(String name);

}
