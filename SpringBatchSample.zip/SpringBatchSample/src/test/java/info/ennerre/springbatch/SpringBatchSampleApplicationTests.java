package info.ennerre.springbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
