package info.ennerre.springbatch.tasks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RunnableTask implements Runnable {

	private static final Logger log = LoggerFactory.getLogger(RunnableTask.class);

	private final String message;

	public RunnableTask(String message) {
		this.message = message;
	}

	@Override
	public void run() {
		log.debug("RunnableTask started on {}", Thread.currentThread().getName());
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			log.debug("Awake by exception");
		}
		log.debug("RunnableTask message = '{}' on thread '{}'", message, Thread.currentThread().getName());
	}

}
