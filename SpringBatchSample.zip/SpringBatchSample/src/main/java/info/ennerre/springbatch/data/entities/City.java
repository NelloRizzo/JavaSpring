package info.ennerre.springbatch.data.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "cities")
@Data
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
@NoArgsConstructor
@ToString(callSuper = true)
public class City extends BaseEntity {
	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	private String name;
	@Column(columnDefinition = "CHAR(2)", nullable = false)
	private String province;
	@Column(columnDefinition = "CHAR(4)", nullable = false)
	private String code;

	@Builder(setterPrefix = "with")
	public City(long id, Date createdAt, String name, String province, String code) {
		super(id, createdAt);
		this.name = name;
		this.province = province;
		this.code = code;
	}
}
