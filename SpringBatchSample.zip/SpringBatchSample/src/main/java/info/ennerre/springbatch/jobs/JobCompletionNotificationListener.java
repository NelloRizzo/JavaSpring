package info.ennerre.springbatch.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import info.ennerre.springbatch.data.entities.City;

@Component
public class JobCompletionNotificationListener implements JobExecutionListener {
	private static final Logger log = LoggerFactory.getLogger(JobCompletionNotificationListener.class);

	private final JdbcTemplate jdbcTemplate;

	public JobCompletionNotificationListener(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			log.info("!!! JOB FINISHED! Time to verify the results");

			jdbcTemplate.query("SELECT id, created_at, name, province, code FROM cities LIMIT 10", //
					(rs, row) -> City.builder() //
							.withCode(rs.getString(5)) //
							.withName(rs.getString(3)) //
							.withProvince(rs.getString(4)) //
							.withId(rs.getLong(1)) //
							.withCreatedAt(rs.getDate(2))//
							.build())
					.forEach(city -> log.info("Found <{{}}> in the database.", city));
		}
	}
}
