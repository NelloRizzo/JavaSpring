package info.ennerre.springbatch.jobs;

import java.nio.charset.StandardCharsets;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.transaction.PlatformTransactionManager;

import info.ennerre.springbatch.data.entities.City;

@Configuration
public class CitiesLoaderBatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(CitiesLoaderBatchConfiguration.class);

	@Value("classpath:res/comuni.csv")
	Resource file;

	@Bean
	FlatFileItemReader<City> reader() {
		log.debug("Configuring reader...");
		return new FlatFileItemReaderBuilder<City>() //
				.encoding(StandardCharsets.ISO_8859_1.name()) //
				.linesToSkip(3) //
				.name("cityItemReader") //
				.lineMapper((l, n) -> {
					var p = l.split(";");
					var city = City.builder() //
							.withCode(p[19].trim()) //
							.withName(p[6].trim()) //
							.withProvince(p[14].trim())
							.build();
					log.debug("Mapped {}", city);
					return city;
				}) //
				.resource(file) //
				.build();
	}

	@Bean
	ItemProcessor<City, City> cityProcessor() {
		return new ItemProcessor<City, City>() {
			@Override
			public City process(City item) throws Exception {
				log.debug("Converting {}", item);
				return item;
			}
		};
	}

	@Bean
	JdbcBatchItemWriter<City> writer(DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<City>() //
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>()) //
				.sql("INSERT INTO cities(name, province, code) VALUES(:name, :province, :code)") //
				.dataSource(dataSource) //
				.build();
	}

	@Bean
	Job importCityJob(JobRepository repo, JobCompletionNotificationListener listener, Step step1) {
		return new JobBuilder("importCity", repo) //
				.listener(listener) //
				.flow(step1) //
				.end() //
				.build();
	}

	@Bean
	Step step1(JobRepository repo, //
			PlatformTransactionManager transactionManager, //
			JdbcBatchItemWriter<City> writer) {
		return new StepBuilder("step1", repo) //
				.<City, City>chunk(10, transactionManager) //
				.reader(reader()) //
				.processor(cityProcessor()) //
				.writer(writer) //
				.build();
	}
}
