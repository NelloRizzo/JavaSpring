package info.ennerre.springbatch.runners;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.PeriodicTrigger;
import org.springframework.stereotype.Component;

import info.ennerre.springbatch.tasks.RunnableTask;

@Component
public class TriggerRunner implements CommandLineRunner {
	private static final Logger log = LoggerFactory.getLogger(TriggerRunner.class);
	@Autowired
	TaskScheduler scheduler;

	@Value("${runner.triggers.enabled}")
	boolean enabled;

	@Value("${pool.size}")
	int poolSize;

	@Override
	public void run(String... args) throws Exception {
		if (enabled) {
			log.debug("Configuring periodic task");
			var p = new PeriodicTrigger(Duration.ofMillis(300));
			scheduler.schedule(new RunnableTask("Periodic task"), p);
		} else
			log.debug("TriggerRunner disabled");
	}

}
