package info.ennerre.springbatch.tasks;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

@Configuration
public class TaskSchedulingConfiguration {

	@Value("${pool.size}")
	int poolSize;

	@Value("${runner.tasks.scheduler}")
	String schedulerClassName;

	@Bean
	TaskScheduler getPoolTaskScheduler() {
		TaskScheduler scheduler;
		if (schedulerClassName.equalsIgnoreCase("concurrent"))
			scheduler = new ConcurrentTaskScheduler();
		else if (schedulerClassName.equalsIgnoreCase("pool")) {
			scheduler = new ThreadPoolTaskScheduler();
			((ThreadPoolTaskScheduler) scheduler).setPoolSize(poolSize);
			((ThreadPoolTaskScheduler) scheduler).setThreadNamePrefix("info.ennerre.");
		} else
			throw new RuntimeException("No scheduler provided");
		return scheduler;
	}
}
