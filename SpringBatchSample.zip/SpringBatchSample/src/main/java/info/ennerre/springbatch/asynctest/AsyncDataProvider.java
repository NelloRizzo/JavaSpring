package info.ennerre.springbatch.asynctest;

import java.util.concurrent.CompletableFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class AsyncDataProvider {

	private static final Logger log = LoggerFactory.getLogger(AsyncDataProvider.class);

	@Async
	public void handleDataAsync() {
		log.debug("Start async method on thread {}", Thread.currentThread().getName());
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			log.error("Sleep interrupted!");
		}
		log.debug("Async method done on thread {}", Thread.currentThread().getName());
	}

	@Async
	public CompletableFuture<String> getDataAsync(String text) {
		log.debug("Start async method on thread {} with input <{}>", Thread.currentThread().getName(), text);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			log.error("Sleep interrupted!");
		}
		var result = String.format("Text handled on thread %s: %s", Thread.currentThread().getName(),
				text.toUpperCase());
		log.debug("Async method done with result: {}", result);
		return CompletableFuture.completedFuture(result);
	}
}
