package info.ennerre.springbatch.runners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import info.ennerre.springbatch.asynctest.AsyncDataProvider;

@Component
public class AsyncRunner implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(AsyncRunner.class);
	@Autowired
	AsyncDataProvider provider;

	@Value("${async.subscribe}")
	boolean subscribe;

	@Override
	public void run(String... args) throws Exception {
		log.debug("Invoking an asynchronous method on thread {}", Thread.currentThread().getName());
		if (!subscribe) {
			var future = provider.getDataAsync("Test");

			while (true) {
				if (future.isDone()) {
					log.debug("Result from asynchronous process: {} ", future.get());
					break;
				}
				log.debug("I'm waiting...");
				Thread.sleep(1000);
			}
		} else {
			provider.getDataAsync("Test") //
//					.thenAccept(result -> log.debug("Async done: {}", result))
					.thenApply(result -> {
						log.debug("Result: {}", result);
						return result.length();
					}) //
					.thenAccept(l -> //
					log.debug("Len of result string is of {} chars", l));
			log.debug("I still working...");
		}
		log.debug("AsyncRunner is done...");
	}

}
