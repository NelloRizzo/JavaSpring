package info.ennerre.springbatch.runners;

import java.time.Instant;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import info.ennerre.springbatch.tasks.RunnableTask;

@Component
public class TasksRunner implements CommandLineRunner {
	private static final Logger log = LoggerFactory.getLogger(TasksRunner.class);

	@Autowired
	TaskScheduler scheduler;

	@Value("${runner.tasks.enabled}")
	boolean enabled;

	@Value("${pool.size}")
	int poolSize;

	@Override
	public void run(String... args) throws Exception {
		if (enabled) {
			log.debug("Scheduling tasks on pool of {} threads", poolSize);
			IntStream.range(1, 11) //
					.forEach(n -> {
						var taskName = "Task" + n;
						log.debug("{} configured", taskName);
						scheduler.schedule( //
								new RunnableTask(taskName), //
								Instant.now().plusMillis(3000));
					});
		} else
			log.debug("TasksRunner disabled");
	}

}
