package it.begear.italiancities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComuniItaliani1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
