package it.begear.italiancities;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import it.begear.italiancities.dao.CitiesDao;
import it.begear.italiancities.entities.City;

@Component
public class JdbcCitiesDao extends JdbcDao<City> implements CitiesDao {

	@Override
	protected String getInsert() {
		return "insert into cities(id,code,capital,name,province_id) values(?,?,?,?,?); ";
	}

	@Override
	protected String getSelectAll() {
		return "select id,code,capital,name,province_id from cities; ";
	}

	@Override
	protected String getSelectById() {
		return "select id,code,capital,name,province_id from cities where id = ?; ";
	}

	@Override
	protected String getUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected String getDelete() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected RowMapper<City> getRowMapper() {
		return (r, i) -> new City( //
				r.getInt(1), r.getString(4), null, //
				r.getString(2), r.getBoolean(3));
	}

}
