package it.begear.italiancities.dao;

import it.begear.italiancities.entities.Area;

public interface AreasDao extends Dao<Area> {

}
