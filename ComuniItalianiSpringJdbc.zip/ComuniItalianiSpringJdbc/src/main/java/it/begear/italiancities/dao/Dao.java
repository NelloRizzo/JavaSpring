package it.begear.italiancities.dao;

import java.util.List;

public interface Dao<T> {
	public void create(T entity);

	public T readById(Long id);

	public List<T> readAll();

	public void update(T entity);

	public void delete(Long id);
}
