package it.begear.italiancities.dao;

import it.begear.italiancities.entities.Region;

public interface RegionsDao extends Dao<Region> {

}
