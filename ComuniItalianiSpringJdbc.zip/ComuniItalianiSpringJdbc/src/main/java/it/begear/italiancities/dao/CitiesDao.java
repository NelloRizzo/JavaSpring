package it.begear.italiancities.dao;

import it.begear.italiancities.entities.City;

public interface CitiesDao extends Dao<City>{

}
