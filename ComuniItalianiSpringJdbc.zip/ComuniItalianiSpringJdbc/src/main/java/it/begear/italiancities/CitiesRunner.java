package it.begear.italiancities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.begear.italiancities.dao.CitiesDao;

@Component
public class CitiesRunner implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(CitiesRunner.class);
	@Autowired
	CitiesDao cities;

	@Override
	public void run(String... args) throws Exception {
		cities.readAll().forEach(c -> logger.debug("{}", c));

	}

}
