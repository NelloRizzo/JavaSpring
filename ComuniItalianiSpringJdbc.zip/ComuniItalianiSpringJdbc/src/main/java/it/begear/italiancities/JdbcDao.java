package it.begear.italiancities;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import it.begear.italiancities.dao.Dao;

public abstract class JdbcDao<T> implements Dao<T> {

	@Autowired
	JdbcTemplate jdbc;

	protected abstract String getInsert();

	protected abstract String getSelectAll();

	protected abstract String getSelectById();

	protected abstract String getUpdate();

	protected abstract String getDelete();

	protected abstract RowMapper<T> getRowMapper();

	@Override
	public void create(T entity) {
		// TODO Auto-generated method stub

	}

	@Override
	public T readById(Long id) {
		return jdbc.queryForObject(getSelectById(), getRowMapper(), id);
	}

	@Override
	public List<T> readAll() {
		return jdbc.query(getSelectAll(), getRowMapper());
	}

	@Override
	public void update(T entity) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub

	}

}
