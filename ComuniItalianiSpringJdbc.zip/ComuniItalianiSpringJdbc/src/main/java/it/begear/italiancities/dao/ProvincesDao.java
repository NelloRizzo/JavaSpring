package it.begear.italiancities.dao;

import it.begear.italiancities.entities.Province;

public interface ProvincesDao extends Dao<Province> {

}
