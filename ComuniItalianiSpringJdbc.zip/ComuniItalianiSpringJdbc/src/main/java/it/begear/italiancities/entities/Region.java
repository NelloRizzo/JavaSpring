package it.begear.italiancities.entities;

import java.util.Objects;

public class Region {
	private int id;
	private String name;
	private Area area;

	public Region(int id, String name, Area area) {
		this.id = id;
		this.name = name;
		this.area = area;
	}

	public Region() {
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Area getArea() {
		return area;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Region other = (Region) obj;
		return id == other.id;
	}

	@Override
	public String toString() {
		return "Region [id=" + id + ", name=" + name + ", area=" + area + "]";
	}

}
