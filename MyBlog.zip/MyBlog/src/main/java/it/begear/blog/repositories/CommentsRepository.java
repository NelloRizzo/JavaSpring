package it.begear.blog.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import it.begear.blog.entities.Comment;

public interface CommentsRepository extends JpaRepository<Comment, Long>{

}
