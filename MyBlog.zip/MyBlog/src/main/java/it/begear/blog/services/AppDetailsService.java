package it.begear.blog.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import it.begear.blog.repositories.UsersRepository;
import it.begear.blog.services.models.AppUserDetails;

@Service
public class AppDetailsService implements UserDetailsService {

	@Autowired
	UsersRepository users;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return AppUserDetails.build(users.findByUsername(username) //
				.orElseThrow(() -> new UsernameNotFoundException(username)));
	}

}
