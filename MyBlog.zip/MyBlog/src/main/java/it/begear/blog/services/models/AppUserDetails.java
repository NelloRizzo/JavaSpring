package it.begear.blog.services.models;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import it.begear.blog.entities.User;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AppUserDetails implements UserDetails {
	private static final long serialVersionUID = 1L;
	private Collection<? extends GrantedAuthority> authorities;
	private String password;
	private String username;
	private boolean accountNonExpired;
	private boolean accountNonLocked;
	private boolean credentialsNonExpired;
	private boolean enabled;

	public static AppUserDetails build(User user) {
		var roles = user.getRoles().stream() //
				.map(r -> new SimpleGrantedAuthority(r.getName().name())).toList();
		return new AppUserDetails(roles, user.getPassword(), //
				user.getUsername(), true, true, true, true);
	}
}
