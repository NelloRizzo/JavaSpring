package it.begear.blog.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(setterPrefix = "with")
@Entity
@Table(name = "articles")
public class Article {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(columnDefinition = "VARCHAR(80)", nullable = false)
	private String title;
	@Column(columnDefinition = "MEDIUMTEXT", nullable = false)
	private String content;
	@Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date publishedAt;
	@Column(columnDefinition = "VARCHAR(20)", nullable = false)
	private String author;
	@OneToMany(mappedBy = "article")
	private final Set<Comment> comments = new HashSet<>();
}
