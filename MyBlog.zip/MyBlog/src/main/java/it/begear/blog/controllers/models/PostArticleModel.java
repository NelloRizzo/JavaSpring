package it.begear.blog.controllers.models;

import lombok.Data;

@Data
public class PostArticleModel {
	private String title;
	private String content;
}
