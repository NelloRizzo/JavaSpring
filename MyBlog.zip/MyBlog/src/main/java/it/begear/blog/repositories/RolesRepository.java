package it.begear.blog.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import it.begear.blog.entities.Role;

public interface RolesRepository extends JpaRepository<Role, Long> {

}
