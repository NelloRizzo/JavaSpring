package it.begear.blog.controllers.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponseModel {
	private String token;
	private String username;
	private List<String> roles;
}
