package it.begear.blog.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import it.begear.blog.services.AppDetailsService;

@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig {

	private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);
	@Autowired
	AppDetailsService users;

	@Autowired
	private AuthEntryPointUnauthorizedJwt unauth;

	@Bean
	AuthorizationTokenFilter getFilter() {
		return new AuthorizationTokenFilter();
	}

	@Bean
	PasswordEncoder getEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}

	@Bean
	AuthenticationManager getAuthenticationManager(HttpSecurity http) throws Exception {
		logger.debug("getAuthenticationManager() done");
		return http.getSharedObject(AuthenticationManagerBuilder.class) //
				.userDetailsService(users).passwordEncoder(getEncoder()) //
				.and().build();
	}

	@Bean
	SecurityFilterChain getFilterChain(HttpSecurity http) throws Exception {
		http.cors(c -> c.disable()).csrf(c -> c.disable()) //
				.exceptionHandling(h -> h.authenticationEntryPoint(unauth)) //
				.sessionManagement(m -> m.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) //
				.authorizeHttpRequests().requestMatchers("/**").permitAll().anyRequest().authenticated();
		http.addFilterBefore(getFilter(), UsernamePasswordAuthenticationFilter.class);
		logger.debug("getFilterChain() done");
		return http.build();
	}
}
