package it.begear.blog.controllers.models;

import lombok.Data;

@Data
public class LoginRequestModel {
	private String username;
	private String password;
}
