package it.begear.blog.controllers.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegisterResponseModel {
	private Long id;
	private String username;
}
