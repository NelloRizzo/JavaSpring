package it.begear.blog.services;

import java.util.List;
import java.util.Optional;

import it.begear.blog.entities.Article;

public interface BlogService {
	public List<Article> getAllArticles();

	public List<Article> getAllArticlesByUser(String username);
	
	public Optional<Article> getById(long id);
	
	public Article post(Article article);
}
