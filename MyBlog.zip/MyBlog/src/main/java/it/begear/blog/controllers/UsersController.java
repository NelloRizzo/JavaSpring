package it.begear.blog.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.begear.blog.controllers.models.LoginRequestModel;
import it.begear.blog.controllers.models.LoginResponseModel;
import it.begear.blog.controllers.models.RegisterResponseModel;
import it.begear.blog.entities.User;
import it.begear.blog.repositories.UsersRepository;
import it.begear.blog.services.JwtHelper;
import it.begear.blog.services.models.AppUserDetails;
import jakarta.annotation.security.PermitAll;

@RestController
@RequestMapping("/api/users")
public class UsersController {

	@Autowired
	AuthenticationManager manager;
	@Autowired
	UsersRepository users;

	@Autowired
	JwtHelper jwt;

	@PostMapping("/login")
	public ResponseEntity<LoginResponseModel> authenticate(@RequestBody LoginRequestModel login) {
		var auth = manager.authenticate( //
				new UsernamePasswordAuthenticationToken( //
						login.getUsername(), login.getPassword()));
		auth.getAuthorities();
		SecurityContextHolder.getContext().setAuthentication(auth);
		var token = jwt.generate(auth);
		var u = (AppUserDetails) auth.getPrincipal();
		var roles = u.getAuthorities().stream().map(r -> r.getAuthority()).toList();
		return ResponseEntity.ok(new LoginResponseModel(token, u.getUsername(), roles));
	}

	@PermitAll
	@PostMapping("/register")
	public ResponseEntity<RegisterResponseModel> register(@RequestBody LoginRequestModel login) {
		var u = new User(0l, login.getUsername(), login.getPassword());
		users.save(u);
		u = users.findByUsername(login.getUsername()).orElseThrow();
		return ResponseEntity.ok(new RegisterResponseModel(u.getId(), u.getUsername()));
	}
}
