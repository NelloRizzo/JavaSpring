package it.begear.blog.configuration;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import it.begear.blog.services.JwtHelper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuthorizationTokenFilter extends OncePerRequestFilter {
	private static final Logger logger = LoggerFactory.getLogger(AuthorizationTokenFilter.class);
	public static final String TOKEN_TYPE = "Bearer ";
	public static final String HEADER_NAME = "Authorization";

	@Autowired
	JwtHelper jwt;

	@Autowired
	UserDetailsService users;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			var header = request.getHeader(HEADER_NAME);
			if (header != null && header.startsWith(TOKEN_TYPE)) {
				var token = header.substring(TOKEN_TYPE.length());
				var username = jwt.getUsername(token);
				var user = users.loadUserByUsername(username);

				var auth = new UsernamePasswordAuthenticationToken( //
						user, null, user.getAuthorities());
				auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(auth);
			}
		} catch (Exception e) {
			logger.error("{}", e);
		}

		filterChain.doFilter(request, response);
	}

}
