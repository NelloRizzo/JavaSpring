package it.begear.blog.services.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.begear.blog.entities.Article;
import it.begear.blog.repositories.ArticlesRepository;
import it.begear.blog.services.BlogService;

@Service
public class BlogServiceImpl implements BlogService {

	@Autowired
	ArticlesRepository articles;

	@Override
	public List<Article> getAllArticles() {
		return articles.findAll();
	}

	@Override
	public List<Article> getAllArticlesByUser(String username) {
		return articles.findAllByAuthor(username);
	}

	@Override
	public Article post(Article article) {
		articles.save(article);
		return article;
	}

	@Override
	public Optional<Article> getById(long id) {
		return articles.findById(id);
	}

}
