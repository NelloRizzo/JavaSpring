package it.begear.blog.configuration;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.begear.blog.entities.RoleType;
import it.begear.blog.entities.Role;
import it.begear.blog.repositories.RolesRepository;

@Component
public class PopulateRolesRunner implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(PopulateRolesRunner.class);
	@Autowired
	RolesRepository repo;

	@Override
	public void run(String... args) throws Exception {
		if (repo.count() == 0) {
			Arrays.asList(RoleType.values()).forEach(r -> {
				repo.save(new Role(0l, r));
				logger.debug("Saved {} role", r);
			});
		}

	}

}
