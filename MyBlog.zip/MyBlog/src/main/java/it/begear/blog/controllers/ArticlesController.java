package it.begear.blog.controllers;

import java.net.URI;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.begear.blog.controllers.models.PostArticleModel;
import it.begear.blog.entities.Article;
import it.begear.blog.services.BlogService;

@RestController
@RequestMapping("/api/blog")
public class ArticlesController {

	@Autowired
	BlogService service;

	@PreAuthorize("isAuthenticated()")
	@PostMapping
	public ResponseEntity<Article> post(@RequestBody PostArticleModel article) {
		var u = SecurityContextHolder.getContext().getAuthentication().getName();
		var a = Article.builder() //
				.withTitle(article.getTitle()) //
				.withContent(article.getContent()) //
				.withPublishedAt(new Date()).withAuthor(u).build();
		a = service.post(a);
		return ResponseEntity.created( //
				URI.create(String.format("/api/blog/%d", a.getId()))) //
				.body(a);
	}

	@GetMapping("{id}")
	public ResponseEntity<Article> get(@PathVariable long id) {
		return ResponseEntity.ok(service.getById(id).orElseThrow());
	}
}
