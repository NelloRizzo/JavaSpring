package it.begear.blog.services;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import it.begear.blog.services.models.AppUserDetails;

@Component
public class JwtHelper {
	private static final Logger logger = LoggerFactory.getLogger(JwtHelper.class);

	@Value("${jwt.secretkey}")
	private String encriptionKey;

	@Value("${jwt.expirationtime}")
	private Long expiration;

	public String generate(Authentication auth) {
		var ud = (AppUserDetails) auth.getPrincipal();
		var now = new Date();
		var expires = new Date(now.getTime() + expiration);
		return Jwts.builder() //
				.setSubject(ud.getUsername()) //
				.setIssuedAt(now) //
				.setExpiration(expires) //
				.signWith(SignatureAlgorithm.HS512, encriptionKey) //
				.compact();
	}

	public boolean validate(String token) {
		try {
			Jwts.parser().setSigningKey(encriptionKey).parseClaimsJws(token);
			return true;
		} catch (Exception e) {
			logger.error("validate() -> Invalid token: {}", e.getMessage());
		}
		return false;
	}

	public String getUsername(String token) {
		try {
			var u = Jwts.parser() //
					.setSigningKey(encriptionKey).parseClaimsJws(token) //
					.getBody().getSubject();
			logger.debug("Username from token: {}", u);
			return u;
		} catch (Exception e) {
			logger.error("getUsername() -> Invalid token: {}", e.getMessage());
		}
		return null;
	}
}
