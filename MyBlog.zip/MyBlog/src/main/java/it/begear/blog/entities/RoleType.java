package it.begear.blog.entities;

public enum RoleType {
	Admin, User
}
